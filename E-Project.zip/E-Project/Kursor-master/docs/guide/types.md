# Types 

The property that changes the cursor is `type` and at the moment we only have **5** types of cursors:

### Type 1 (Default)

<Types-1/>

### Type 2

<Types-2/>

### Type 3

<Types-3/>

### Type 4

<Types-4/>

### Type 5

<Types-5/>
