# Introduction

Kursor is a javascript library to implement a cursor (mouse) on the website, it is very simple to implement and with many types of themes to choose from

## Example

The cursor (mouse) that you are seeing right now in this site is a perfect example of what you can achieve with kursor, and most importantly with few lines of code and very easy

